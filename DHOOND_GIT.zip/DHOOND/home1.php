<html>
    <head>
        <link rel="stylesheet" href="home1.css" type="text/css">
    </head>
    <body> 
    <header>
  <img src="dhoondlogo1.jpg" alt="Your Image" height="100px" width="350px">
    <ul>
    <li><a href="fretrieve.php">The Found Directory</a></li>
    <li><a href="retrieve.php">The Lost Directory</a></li>
    </ul>
  
</header>
    <div class="columns">
        <div class="column1">
            <form action="lostform.html">
            <button class="button" onclick="">Lost Something</button>
            </form>
        </div>
        <div class="column2">
            <form action="foundform.html">
            <button class="button">Found Something</button>
            </form>
        </div>
    </div>
    </body>
</html>