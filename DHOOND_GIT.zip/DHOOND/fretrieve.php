<html>
<head>
        <link rel="stylesheet" href="display.css" type="text/css">
        </head>
<body> 
<div class="header">
            <img src="dhoondlogo1.jpg" height="100px" width="350px">

</div>
<h1>The Found Items Directory</h1>
 <form action="" method="post" enctype="multipart/form-data">
           <table class="ldisplay">
            <thead>
            <tr></tr>
                <th>IDNO</th>
                <th>Name</th>
                <th>ITEM</th>
                <th>DESCRIPTION</th>
                <th>DATE(FOUND)</th>
                <th>PLACE(FOUND)</th>
                <th>IMAGE</th>
            </tr>
            </thead>
            <?php
            $connection = mysqli_connect("localhost"," "," ");
            $db = mysqli_select_db($connection,'dhoond');

            $query = "SELECT * FROM fform ";
            $query_run = mysqli_query($connection, $query);

            while($row = mysqli_fetch_array($query_run))
            {
                ?>
                <tr>
                    <td><?php echo $row['IDNOF']; ?> </td>
                    <td><?php echo $row['UNAME']; ?> </td>
                    <td><?php echo $row['OBJ']; ?> </td>
                    <td><?php echo $row['OBJDES']; ?> </td>
                    <td><?php echo $row['FDATE']; ?> </td>
                    <td><?php echo $row['FPLACE']; ?> </td>
                    <td><?php echo '<img src="data:image;base64,'.base64_encode($row['OBJIMG']).'" alt="Image not available" style="width : 100px; height : 150px;">';
                    ?></td>
                <?php


            }
            ?>
           </table> 
         </form>
    </body>
</html>