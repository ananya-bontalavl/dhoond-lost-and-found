<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get input values
    $idno = trim($_POST["idno"]);
    $uname = trim($_POST["uname"]);
    $loc = trim($_POST["loc"]);
    $pwrd = trim($_POST["pwrd"]);

    // Validate input
    if (empty($idno)) {
        die("Error: ID number is required.");
    }
    if (empty($uname)) {
        die("Error: Username is required.");
    }
    if (empty($loc)) {
        die("Error: Location is required.");
    }
    if (empty($pwrd)) {
        die("Error: Password is required.");
    }

    // Hash password
    //$password_hash = password_hash($pwrd, PASSWORD_DEFAULT);

    // Set database credentials
    $host = "localhost";
    $dbname = "dhoond";
    $username = " ";
    $password = " ";

    // Create database connection
    $conn = mysqli_connect($host, $username, $password, $dbname);

    // Check for connection errors
    if (!$conn) {
        die("Connection error: " . mysqli_connect_error());
    }

    // Prepare and execute SQL statement
    $sql = "INSERT INTO register (IDNO, UNAME, LOC, pwrd) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssss", $idno, $uname, $loc, $pwrd);

    if (mysqli_stmt_execute($stmt)) {
        echo "Registered successfully.";
		header("Location: login.php");
		exit;
	
	} 
	else {
        die("Error: " . mysqli_stmt_error($stmt));
    }

    // Close database connection
    mysqli_close($conn);
}
?>
