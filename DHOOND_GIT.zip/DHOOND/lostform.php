<?php
$idno_= $_POST['idnol'];
$uname = $_POST['uname'];
$obj= $_POST['obj'];
$objdes= $_POST['objdes'];
$ldate= $_POST['ldate'];
$lplace= $_POST['lplace'];
$phno= $_POST['phno'];
$objimg= file_get_contents($_FILES["objimg"]["tmp_name"]);

$host = "localhost";
$dbname="dhoond";
$username= " ";
$password = " ";

$conn = mysqli_connect(hostname:$host,
               username: $username,
			   password: $password,
			   database: $dbname);

if(mysqli_connect_errno()){
die("Connection Error: " . mysqli_connect_error());
}
$sql = "INSERT INTO lform (idnol, uname, obj, objdes, ldate, lplace, phno, objimg) VALUES(?,?,?,?,?,?,?,?)";
$stmt= mysqli_stmt_init($conn);



if(! mysqli_stmt_prepare($stmt, $sql)){
	die(mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "ssssssis",$idnol,$uname,$obj,$objdes,$ldate,$lplace,$phno,$objimg);


mysqli_stmt_execute($stmt);

echo "Query Submitted Succesfully";
?>
