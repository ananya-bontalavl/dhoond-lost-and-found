<?php
   define('DB_SERVER', 'localhost:3036');
   define('DB_USERNAME', ' ');
   define('DB_PASSWORD', ' ');
   define('DB_DATABASE', 'dhoond');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>