<?php
$idno= $_POST['idnof'];
$uname= $_POST['uname'];
$obj= $_POST['obj'];
$objdes= $_POST['objdes'];
$fdate= $_POST['fdate'];
$fplace= $_POST['fplace'];
$objimg= file_get_contents($_FILES["objimg"]["tmp_name"]);

$host = "localhost";
$dbname="dhoond";
$username= " ";
$password = " ";

$conn = mysqli_connect(hostname:$host,
               username: $username,
			   password: $password,
			   database: $dbname);

 if(mysqli_connect_errno()){
    die("Connection Error: " . mysqli_connect_error());
    }
$sql = "INSERT INTO fform(idnof,uname,obj,objdes,fdate,fplace,objimg) VALUES(?,?,?,?,?,?,?)";
$stmt= mysqli_stmt_init($conn);

if(! mysqli_stmt_prepare($stmt,$sql)){
    die(mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "sssssss",$idnof,$uname,$obj,$objdes,$fdate,$fplace,$objimg);

mysqli_stmt_execute($stmt);

echo"Query Submitted Succesfully";
?>