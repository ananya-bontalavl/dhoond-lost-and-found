<?php
session_start();

if (isset($_POST['idno']) && isset($_POST['pwrd'])) {

    // Connect to database
    $conn = mysqli_connect('localhost', '', ' ', 'dhoond');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare SQL statement to fetch user data
    $sql = "SELECT * FROM register WHERE IDNO = ? AND pwrd = ?";
    $stmt = mysqli_prepare($conn, $sql);

    // Bind parameters to SQL statement
    mysqli_stmt_bind_param($stmt, "ss", $_POST['idno'], $_POST['pwrd']);

    // Execute SQL statement
    mysqli_stmt_execute($stmt);

    // Fetch user data
    $result = mysqli_stmt_get_result($stmt);

    // Check if user exists
    if ($row = mysqli_fetch_assoc($result)) {

        // Store user IDNO in session variable
        $_SESSION['idno'] = $row['IDNO'];

        // Redirect to home1.php
        header("Location: home1.php");
        exit();

    } else {

        // Display error message
        $error = "Wrong credentials";
    }

    // Close database connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title> DHOOND: LOGIN</title>
        <link rel="stylesheet" href="login.css" type="text/css">
        <style>* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}</style>
    </head>
    <body class="bg">
        <div class="columns">
            <div class="column"> 
                <img src="dhoondlogo.jpg">
            </div>
            <div class="column2">
                <h2>Login to continue on DHOOND.</h2>
                <form class="login" method="post">
                    <label for="idno">Enter ID Number:</label><br>
                    <input type="text" id="idno" name="idno" required><br><br>
                    <label for="pwrd">Enter Login Password:</label><br>
                    <input type="password" id="pwrd" name="pwrd" required><br><br>
                    <?php if (isset($error)) { ?>
                        <p style="color:red"><?php echo $error ?></p>
                    <?php } ?>
                    <input type="submit" value="Login" class="button">
                    <br>
                    <br>
                    <p>Not signed up yet? <a href="register.html">Register</a> here!</p>
                </form>
            </div>
        </div>
    </body>
</html>
